Pérez Jacome David
316330420



Notas:

Se tuvo dificultad al realizar varias partes de la practica, en especial la parte 3 y 4 de la parte 2, ademas para evitar amontonar codigo
se implementaron 2 archivos relacionados con la parte 1

para ejecutarlo se debe tener instalado netlogo, ademas de con base a el archivo estan definidas mediante sladers la forma de variar los parametros iniciales

en los archivos, se debe modificar el tamañaño del mundo mediante click derecho y definir los parametros.