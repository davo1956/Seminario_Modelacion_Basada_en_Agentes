Pérez Jacome David
316330420



Notas:

Se tuvo dificultad al realizar la parte de distanciamiento social, por cuestiones de tiempo y que me confundi al hacer la practica no me fue posible acabar la implementacion del punto 4.
en las variables globales:
POB esta en paramwtros de 1000-10000
PC esta en parametros de 0.50 como el 50% por ejemplo
lo que tuve dificultad es que el distanciamiento debe de ser de igual tamaño a POB si no nos marca un error.