Pérez Jacome David
316330420



Notas:

La ejecución es en Netlogo 6.2.0
el archivo es proyecto-final.nlogo

Más especificaciones en el documento de estructura del proyecto.